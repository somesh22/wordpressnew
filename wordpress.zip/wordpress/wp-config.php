<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress-db' );

/** MySQL database username */
define( 'DB_USER', 'wordpress-user' );

/** MySQL database password */
define( 'DB_PASSWORD', 'password' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
//define( 'AUTH_KEY',         'put your unique phrase here' );
//define( 'SECURE_AUTH_KEY',  'put your unique phrase here' );
//define( 'LOGGED_IN_KEY',    'put your unique phrase here' );
//define( 'NONCE_KEY',        'put your unique phrase here' );
//define( 'AUTH_SALT',        'put your unique phrase here' );
//define( 'SECURE_AUTH_SALT', 'put your unique phrase here' );
//define( 'LOGGED_IN_SALT',   'put your unique phrase here' );
//define( 'NONCE_SALT',       'put your unique phrase here' );




define('AUTH_KEY',         '6Z+Bi)>l=-^SN`GLa6~c@3wT;.ax,sHt,iU{gwcYNch92Hw+Q@H@nt~Wy1g9;48Q');
define('SECURE_AUTH_KEY',  'zkil%Q/jBu>a:E(})<;vAfAxjF-!f)SD+vW:j%GCB;$V3+4Lk@uZ(/39s0 ^a+?3');
define('LOGGED_IN_KEY',    '{eEr%SS9 f#3j+fQ<-8:+z(Gs|2`V&:-N1.(wJp^d{.H@`4o,sv9:j5]7Z{8AaY7');
define('NONCE_KEY',        '.IZ(st5CUULp>;XQl33Y4j`tlMdoC+i|&N2Rw|$f=0Tvw?`hSeHL>~E;6-pV[Y0i');
define('AUTH_SALT',        'd+5ShC4{=] H`&pTVOprb|/5B}K%zaJ+I@-Y5^:4Qxpv6ix}/$|@<+w9|Vp;O=z,');
define('SECURE_AUTH_SALT', 'R-/B:uJ%J_N-UE*Dn*o-[GS|WD,C`4PXLbh.lur1% w{o3MD:P$1_k,2^A6tx0{w');
define('LOGGED_IN_SALT',   '`vFkQpBK^lIPPYP%O)CieE#WDY*A+zy(=aZ}<4 #?KZ5@Bghh(gcUXf1]ij0VwS+');
define('NONCE_SALT',       'kZ^9d} W|s]/;qzX8O#|![T4B/{&UXt/5# >|~gQiaT3|O9Gu[L4`VX&m[8*qINb');
/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
